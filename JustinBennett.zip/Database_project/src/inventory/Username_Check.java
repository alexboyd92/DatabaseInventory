package inventory;

public class Username_Check {
	
	private String username; 
	
	public Boolean valid_username() {
		
		 return this.username.matches("[a-zA-Z0-9\\.]+@[a-zA-Z0-9\\-\\_\\.]+\\.[a-zA-Z0-9]{3}");
	}
	
	public String get_username() {
		return username;
		
	}
	
	public void set_username(String username) {
		this.username = username;
	}

}
