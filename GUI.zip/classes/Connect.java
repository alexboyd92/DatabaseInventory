/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.sql.*;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alexb
 */
public class Connect {
  private java.sql.Connection mycon;
   final String url = "jdbc:mysql://localhost:3306/inv?useSSL=false&serverTimezone=EST";
    		final String username = "root";
    		final String pass = "root";
   Connect(){
       try {
        
            this.mycon = DriverManager.getConnection(url, username, pass);
            mycon.setAutoCommit(false);
       } catch (SQLException ex) {
           Logger.getLogger(Connect.class.getName()).log(Level.SEVERE, null, ex);
       }
    		
   }
   java.sql.Connection getConnection(){
   return this.mycon;}
   
    
}
