/**
 * 
 */
/**
 * @author alexander
 *
 */
module DatabaseInv {
	requires java.sql;
	requires java.desktop;
}